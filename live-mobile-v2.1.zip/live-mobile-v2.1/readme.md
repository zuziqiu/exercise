* live-mobile-v2.1/
    * common/
        * css/ 基础样式文件
        * emotions/ 表情文件
        * js/ 基础配置文件
        * vendor/ 框架&插件
    * css/ 样式文件
    * docs/
    * js/  逻辑目录
    * tpls/ 模板目录
    * live.html* 访问页面


* 使用时需要在 live.html传入正确的access_token秘钥、以及base_path（根目录参数）;