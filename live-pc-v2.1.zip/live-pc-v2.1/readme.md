* live-mobile-v2.1/
    * css/ 样式文件
    * docs/
    * js/  逻辑目录
        * common/ 公共文件
        * libs/ 插件
        * modules/ 模块
        * webuploader/ 插件
    * tpl/ 模板目录
    * live.html* 访问页面


* 使用时需要在 live.html传入正确的access_token秘钥、以及base_path（根目录参数）;